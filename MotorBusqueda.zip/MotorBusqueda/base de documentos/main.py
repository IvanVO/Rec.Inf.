import os.path
import DoubleStemmer as ds
import LSI as lsi
import BaseDeDatos as db
import FreqT as freqt

def main():

    #database = db.BaseDeDatos()
    
    #database.dropCreate()
    lsi_ = lsi.LSI()
    #stemmer = ds.DoubleStemmer()
    #
    #directory = './TestFiles/'
    #list_files = os.listdir(directory)
    #
    #for file in list_files:
    #   if file.endswith(".txt"):    
    #       stemmer.stemText(f"TestFiles/{file}")

    #lsi_.listFiles()
    lsi_.retrieveData()

    freqTMatrix = freqt.FreqT()
    freqTMatrix.printMatrix()

if __name__ == '__main__':
    main()
